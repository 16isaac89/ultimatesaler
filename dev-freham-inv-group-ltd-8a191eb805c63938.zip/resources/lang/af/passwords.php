<?php

return [
    'password' => 'Wagwoorde moet ten minste ses karakters wees en met die bevestiging ooreenstem.',
    'reset'    => 'U wagwoord is herstel!',
    'sent'     => 'Ons het u wagwoord herstel skakel per e-pos aangestuur!',
    'token'    => 'Die wagwoord herstel kenteken is ongeldig.',
    'user'     => 'Ons kon nie \'n gebruiker vind met die e-pos adres nie.',
    'updated'  => 'U wagwoord is verander!',
];
