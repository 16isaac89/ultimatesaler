<?php

return [
    'failed'   => 'Hierdie gegewens strook nie met ons rekords nie.',
    'password' => 'The verskafde wagwoord is verkeerd.',
    'throttle' => 'Teveel aanteken probeerslae. Probeer asseblief in :seconds sekondes.',
];
