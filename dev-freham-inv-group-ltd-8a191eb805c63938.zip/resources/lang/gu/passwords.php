<?php

return [
    'password' => 'પાસવર્ડ ઓછામાં ઓછા છ અક્ષરના હોવા જોઈએ અને પુષ્ટિકરણ સાથે મેળ ખાય છે.',
    'reset'    => 'તમારો પાસવર્ડ રીસેટ કરવામાં આવ્યો છે!',
    'sent'     => 'અમે તમારો પાસવર્ડ રીસેટ લિંક ઈ-મેઈલ કરી છે!',
    'token'    => 'This password reset token is invalid.',
    'user'     => 'We can\'t find a user with that e-mail address.',
    'updated'  => 'Your password has been changed!',
];
