<?php

return [
    'previous' => '« અગાઉના',
    'next'     => 'આગળ »',
];
