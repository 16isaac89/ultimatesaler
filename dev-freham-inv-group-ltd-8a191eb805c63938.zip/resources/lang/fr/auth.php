<?php

return [
    'failed'   => 'Ces identifiants ne sont pas reconnus.',
    'password' => 'Mot de passe erroné.',
    'throttle' => 'Trop d\'echec de tentatives de connexion. Veuillez réessayer dans :seconds secondes.',
];
