<?php

return [
    'previous' => '« Précédent',
    'next'     => 'Suivant »',
];
