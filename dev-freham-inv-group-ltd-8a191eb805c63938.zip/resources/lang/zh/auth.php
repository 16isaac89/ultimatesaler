<?php

return [
    'failed'   => '登入憑證與我們的記錄不符。',
    'password' => '密碼錯誤。',
    'throttle' => '登入錯誤次數過多, 請 :seconds 秒後再試。',
];
