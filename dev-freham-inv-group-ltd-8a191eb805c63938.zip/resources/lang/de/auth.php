<?php

return [
    'failed'   => 'Diese Anmeldeinformationen konnten nicht verifiziert werden.',
    'password' => 'Diese Anmeldeinformationen konnten nicht verifiziert werden.',
    'throttle' => 'Zu viele fehlerhafte Versuche. Bitte versuchen sie es in :seconds Sekunden erneut.',
];
