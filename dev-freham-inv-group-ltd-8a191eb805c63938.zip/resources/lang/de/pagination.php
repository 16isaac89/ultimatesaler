<?php

return [
    'previous' => '&laquo; Vorige',
    'next'     => 'Nächste &raquo;',
];
