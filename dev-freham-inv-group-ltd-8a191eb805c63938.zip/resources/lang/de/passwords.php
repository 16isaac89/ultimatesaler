<?php

return [
    'password' => 'Passwörter müssen mindestens 6 Zeichen lang und identisch sein.',
    'reset'    => 'Ihr Passwort wurde zurückgesetzt!',
    'sent'     => 'Wir haben Ihnen einen Link gesendet!',
    'token'    => 'Das Token ist ungültig.',
    'user'     => 'Wir kennen diese E-Mail-Adresse nicht.',
    'updated'  => 'Das Passwort wurde neu gesetzt!',
];
