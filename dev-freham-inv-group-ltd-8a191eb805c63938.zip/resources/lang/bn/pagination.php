<?php

return [
    'previous' => '& Laquo; আগে',
    'next'     => 'পরবর্তী & raquo;',
];
