<?php

return [
    'previous' => '« Anterior',
    'next'     => 'Siguiente»',
];
