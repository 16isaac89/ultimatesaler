<?php

return [
    'failed'   => 'Queste credenziali non corrispondono a nessuno dei nostri record.',
    'password' => 'La password fornita non è corretta.',
    'throttle' => 'Troppi tentativi di login. Riprovi in :seconds seconds.',
];
