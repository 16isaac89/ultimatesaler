<?php

return [
    'site_title' => 'Freham Inv Group Ltd',
];
